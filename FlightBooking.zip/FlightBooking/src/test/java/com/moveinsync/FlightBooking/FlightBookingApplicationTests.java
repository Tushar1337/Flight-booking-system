package com.moveinsync.FlightBooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
